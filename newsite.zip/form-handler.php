<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * FORM HANDLER — COMPUDON Junior
 * Verifies reCAPTCHA v3, then:
 *   1. Creates a lead in Zoho CRM (if ZOHO_ENABLED is true)
 *   2. Sends a notification email  → connect@compudonjunior.com
 *   3. Sends an auto-acknowledgement → the person who submitted the form
 * Emails are sent via GoDaddy's SMTP server (using PHPMailer), not
 * PHP's built-in mail() function — mail() is unreliable on most
 * modern hosting and often "succeeds" while delivering nothing.
 * ═══════════════════════════════════════════════════════════════
 *
 * DEVELOPER SETUP:
 * 1. Upload this file AND the /phpmailer folder next to it (e.g. both
 *    at the site root: /form-handler.php and /phpmailer/)
 * 2. Fill in SMTP_PASSWORD below with the real password for the
 *    connect@compudonjunior.com mailbox. Nothing will send without it.
 * 3. The SECRET_KEY / SMTP_PASSWORD / Zoho keys below stay on the
 *    server ONLY — never expose them in any HTML/JS file. Ideally
 *    move them to an environment variable or a config file outside
 *    the public web root once live.
 * 4. Point every form's "action" attribute to this file's URL.
 * 5. OPTIONAL — Zoho CRM: fill in ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET,
 *    and ZOHO_REFRESH_TOKEN below, then set ZOHO_ENABLED to true.
 *    See api-console.zoho.com to generate these (Self Client option).
 * ═══════════════════════════════════════════════════════════════
 */

// ── Configuration ──────────────────────────────────────────────
define('RECAPTCHA_SECRET_KEY', '6LdXvlYtAAAAABfO3OtKzTQVRzQazyNx89L9OM8Y');
define('RECAPTCHA_SCORE_THRESHOLD', 0.5); // 0.0 = definitely bot, 1.0 = definitely human
define('NOTIFY_EMAIL', 'connect@compudonjunior.com');
define('SITE_NAME', 'COMPUDON Junior');
define('FROM_EMAIL', 'connect@compudonjunior.com'); // must be a real, existing mailbox — see SMTP settings below

// ── Outgoing email via GoDaddy SMTP (replaces the unreliable PHP mail() function) ──
// Fill in the password for the mailbox above (FROM_EMAIL), then this just works.
define('SMTP_HOST', 'smtpout.secureserver.net');
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl'); // GoDaddy uses SSL on port 465 (use 'tls' + port 587 if 465 is blocked)
define('SMTP_USERNAME', 'connect@compudonjunior.com'); // the mailbox that sends these emails
define('SMTP_PASSWORD', ''); // ← fill this in with that mailbox's actual password

// ── Zoho CRM integration (optional — leave ZOHO_ENABLED false until you have credentials) ──
define('ZOHO_ENABLED', true); // Zoho CRM lead creation is now live
define('ZOHO_CLIENT_ID', '1000.1NOSOBXL3PF69VHSN1ERRDSJ50Z4CX');
define('ZOHO_CLIENT_SECRET', 'c73dce1ae00ded3f6f09e02234886b7bbe4fd3a8ca');
define('ZOHO_REFRESH_TOKEN', '1000.79b9b048335a4a16eddc062d16a7ca6f.eeefd71974b0f0fcb35f6c3a9238854c');
// Use zohoapis.in if your Zoho account was created on the India data center (zoho.com/crm signup
// redirected you to a URL starting with "crm.zoho.in"), otherwise use zohoapis.com.
define('ZOHO_API_DOMAIN', 'https://www.zohoapis.in');
define('ZOHO_ACCOUNTS_DOMAIN', 'https://accounts.zoho.in');

require_once __DIR__ . '/phpmailer/Exception.php';
require_once __DIR__ . '/phpmailer/PHPMailer.php';
require_once __DIR__ . '/phpmailer/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Sends an email via GoDaddy's SMTP server (reliable) instead of PHP's mail()
 * function (unreliable on most modern hosting). Returns true/false for success,
 * and fills $error_out with the reason if it fails.
 */
function send_smtp_email($to, $subject, $html_body, $reply_to, &$error_out) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(FROM_EMAIL, SITE_NAME);
        $mail->addAddress($to);
        if (!empty($reply_to)) {
            $mail->addReplyTo($reply_to);
        }
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $html_body;

        $mail->send();
        return true;
    } catch (PHPMailerException $e) {
        $error_out = $mail->ErrorInfo;
        return false;
    }
}

// ── Only accept POST requests ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// ── Step 1: Verify reCAPTCHA token with Google ─────────────────
$token = $_POST['recaptcha_token'] ?? '';

if (empty($token)) {
    http_response_code(400);
    die('Missing verification token. Please try submitting again.');
}

$verify_url = 'https://www.google.com/recaptcha/api/siteverify';
$verify_data = [
    'secret'   => RECAPTCHA_SECRET_KEY,
    'response' => $token,
    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
];

$ch = curl_init($verify_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($verify_data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

// ── Step 2: Reject if verification failed or score too low ─────
if (!$result || !$result['success'] || ($result['score'] ?? 0) < RECAPTCHA_SCORE_THRESHOLD) {
    http_response_code(403);
    die('We could not verify this submission. Please try again — if this keeps happening, contact us directly at connect@compudonjunior.com.');
}

// ── Step 3: Basic honeypot check (optional extra layer) ────────
// Add a hidden field named "website" to your forms that real users
// never see or fill (via CSS display:none). Bots often fill every field.
if (!empty($_POST['website'])) {
    // Silently pretend success — don't tip off the bot
    http_response_code(200);
    die('Thank you for your submission.');
}

// ── Step 4: Basic rate limiting (simple file-based, per IP) ─────
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rate_limit_file = sys_get_temp_dir() . '/cj_ratelimit_' . md5($ip) . '.txt';
$rate_limit_window = 3600; // 1 hour
$rate_limit_max = 5;       // max 5 submissions per hour per IP

$submissions = [];
if (file_exists($rate_limit_file)) {
    $submissions = json_decode(file_get_contents($rate_limit_file), true) ?: [];
    $submissions = array_filter($submissions, function ($ts) use ($rate_limit_window) {
        return (time() - $ts) < $rate_limit_window;
    });
}

if (count($submissions) >= $rate_limit_max) {
    http_response_code(429);
    die('Too many submissions from this connection. Please try again later, or email us directly at connect@compudonjunior.com.');
}

$submissions[] = time();
file_put_contents($rate_limit_file, json_encode($submissions));

// ── Step 5: Collect form fields (excluding internal fields) ────
$form_name = htmlspecialchars($_POST['form_name'] ?? 'Website Form');
$exclude_fields = ['recaptcha_token', 'website', 'form_name'];

$field_rows = '';
$submitter_email = '';
$submitter_name = '';

foreach ($_POST as $key => $value) {
    if (in_array($key, $exclude_fields)) continue;

    $clean_key = htmlspecialchars(ucwords(str_replace('_', ' ', $key)));
    $clean_value = htmlspecialchars(is_array($value) ? implode(', ', $value) : $value);
    $field_rows .= "<tr><td style='padding:8px 12px;font-weight:600;color:#1F3A5F;border-bottom:1px solid #eee;'>{$clean_key}</td><td style='padding:8px 12px;border-bottom:1px solid #eee;'>{$clean_value}</td></tr>";

    // Try to auto-detect an email field for the acknowledgement
    if (stripos($key, 'email') !== false && filter_var($value, FILTER_VALIDATE_EMAIL)) {
        $submitter_email = $value;
    }
    // Try to auto-detect a name field for personalising the acknowledgement
    if (stripos($key, 'name') !== false && empty($submitter_name)) {
        $submitter_name = $value;
    }
}

// ── Step 5b: Push lead into Zoho CRM (best-effort — never blocks the form) ──
function push_lead_to_zoho($form_name, $fields, $submitter_email, $submitter_name) {
    if (!ZOHO_ENABLED || empty(ZOHO_CLIENT_ID) || empty(ZOHO_REFRESH_TOKEN)) {
        return 'SKIPPED — Zoho not enabled or credentials missing.';
    }

    // 1. Exchange the refresh token for a short-lived access token
    $token_url = ZOHO_ACCOUNTS_DOMAIN . '/oauth/v2/token';
    $token_params = [
        'refresh_token' => ZOHO_REFRESH_TOKEN,
        'client_id'      => ZOHO_CLIENT_ID,
        'client_secret'  => ZOHO_CLIENT_SECRET,
        'grant_type'     => 'refresh_token',
    ];
    $ch = curl_init($token_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    $token_response = curl_exec($ch);
    $token_curl_error = curl_error($ch);
    curl_close($ch);

    if ($token_curl_error) {
        return "FAILED at token step — cURL error: {$token_curl_error} (this usually means outbound HTTPS requests are blocked on your hosting)";
    }

    $token_data = json_decode($token_response, true);
    $access_token = $token_data['access_token'] ?? null;
    if (!$access_token) {
        return "FAILED at token step — Zoho response: " . htmlspecialchars($token_response);
    }

    // 2. Split submitter name into first/last (Zoho's Leads module requires Last_Name)
    $name_parts = preg_split('/\s+/', trim($submitter_name), 2);
    $last_name = $name_parts[1] ?? ($name_parts[0] ?: 'Website Lead');
    $first_name = $name_parts[1] ? $name_parts[0] : '';

    // 3. Build a readable description from every submitted field
    $description_lines = [];
    foreach ($fields as $k => $v) {
        $description_lines[] = ucwords(str_replace('_', ' ', $k)) . ': ' . $v;
    }

    // 4. Try to pick up a school/organisation name if the form had one
    $company = $fields['school_name'] ?? $fields['school'] ?? $fields['company'] ?? SITE_NAME . ' Website Lead';

    $lead_payload = [
        'data' => [[
            'Last_Name'   => $last_name,
            'First_Name'  => $first_name,
            'Email'       => $submitter_email,
            'Phone'       => $fields['phone'] ?? $fields['mobile'] ?? $fields['whatsapp'] ?? '',
            'Company'     => $company,
            'Lead_Source' => 'Website - ' . $form_name,
            'Description' => implode("\n", $description_lines),
        ]],
    ];

    $ch = curl_init(ZOHO_API_DOMAIN . '/crm/v3/Leads');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Zoho-oauthtoken ' . $access_token,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($lead_payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    $lead_response = curl_exec($ch);
    $lead_curl_error = curl_error($ch);
    curl_close($ch);

    if ($lead_curl_error) {
        return "FAILED at lead-creation step — cURL error: {$lead_curl_error}";
    }

    $lead_result = json_decode($lead_response, true);
    if (isset($lead_result['data'][0]['status']) && $lead_result['data'][0]['status'] === 'success') {
        $lead_id = $lead_result['data'][0]['details']['id'] ?? 'unknown';
        return "SUCCESS — Lead created with ID {$lead_id}";
    }

    return "FAILED at lead-creation step — Zoho response: " . htmlspecialchars($lead_response);
}

$clean_fields = array_diff_key($_POST, array_flip($exclude_fields));
$zoho_status = push_lead_to_zoho($form_name, $clean_fields, $submitter_email, $submitter_name);

// ── Step 6: Send notification email to the support team ────────
$notify_subject = "New {$form_name} Submission — " . SITE_NAME;

$notify_body = "
<html><body style='font-family:Arial,sans-serif;color:#333;'>
<div style='max-width:600px;margin:0 auto;'>
  <div style='background:#1F3A5F;padding:20px;text-align:center;'>
    <h2 style='color:#fff;margin:0;'>New Form Submission</h2>
  </div>
  <div style='padding:20px;background:#F4F1EC;'>
    <p><strong>Form:</strong> {$form_name}</p>
    <p><strong>Submitted:</strong> " . date('d M Y, h:i A') . "</p>
    <p><strong>IP Address:</strong> {$ip}</p>
    <p><strong>Spam Score:</strong> " . htmlspecialchars($result['score'] ?? 'N/A') . " (1.0 = human, 0.0 = bot)</p>
    <p><strong>Zoho CRM Status:</strong> " . htmlspecialchars($zoho_status) . "</p>
  </div>
  <table style='width:100%;border-collapse:collapse;margin-top:10px;'>
    {$field_rows}
  </table>
</div>
</body></html>
";

$notify_error = '';
$notify_sent = send_smtp_email(NOTIFY_EMAIL, $notify_subject, $notify_body, $submitter_email, $notify_error);
if (!$notify_sent) {
    error_log('SMTP notify email failed: ' . $notify_error);
}

// ── Step 7: Send auto-acknowledgement to the submitter ──────────
$ack_sent = false;

if (!empty($submitter_email)) {
    $greeting = !empty($submitter_name) ? htmlspecialchars($submitter_name) : 'there';

    $ack_subject = "We've received your submission — " . SITE_NAME;

    $ack_body = "
    <html><body style='font-family:Arial,sans-serif;color:#333;'>
    <div style='max-width:600px;margin:0 auto;'>
      <div style='background:#1F3A5F;padding:24px;text-align:center;'>
        <h2 style='color:#fff;margin:0;'>" . SITE_NAME . "</h2>
      </div>
      <div style='padding:24px;'>
        <p>Hi {$greeting},</p>
        <p>Thank you for your submission to <strong>{$form_name}</strong>. We've received it and our team will review it shortly.</p>
        <p>If you have any urgent questions in the meantime, feel free to reach us directly at <a href='mailto:connect@compudonjunior.com' style='color:#2C7A7B;'>connect@compudonjunior.com</a>.</p>
        <p style='margin-top:24px;'>Warm regards,<br><strong>The COMPUDON Junior Team</strong></p>
      </div>
      <div style='background:#F4F1EC;padding:16px;text-align:center;font-size:12px;color:#777;'>
        CyberLearning Educational Society (Regd.) &middot; Powered by a Microsoft Global Training Partner
      </div>
    </div>
    </body></html>
    ";

    $ack_error = '';
    $ack_sent = send_smtp_email($submitter_email, $ack_subject, $ack_body, '', $ack_error);
    if (!$ack_sent) {
        error_log('SMTP acknowledgement email failed: ' . $ack_error);
    }
}

// ── Step 7b: Write a plain-text debug summary you can view in the browser ──
// Visit https://compudonjunior.com/debug-log.txt after a test submission to see
// exactly what happened. Delete this block (and the file) once everything works.
$debug_log = "=== " . date('d M Y, h:i:s A') . " ===\n";
$debug_log .= "Form: {$form_name}\n";
$debug_log .= "Submitter email detected: " . ($submitter_email ?: '(none found)') . "\n";
$debug_log .= "Zoho CRM Status: {$zoho_status}\n";
$debug_log .= "Notify email sent: " . ($notify_sent ? 'YES' : 'NO — ' . $notify_error) . "\n";
$debug_log .= "Acknowledgement email sent: " . ($ack_sent ? 'YES' : ($submitter_email ? 'NO — ' . ($ack_error ?? 'unknown error') : 'N/A — no submitter email')) . "\n\n";
file_put_contents(__DIR__ . '/debug-log.txt', $debug_log, FILE_APPEND);

// ── Step 8: Respond to the browser ───────────────────────────────
// Redirect to a thank-you page, or return a simple success message.
// Adjust this to redirect to a proper thank-you.html page if you have one.

if ($notify_sent) {
    // Option A: redirect to a thank-you page (recommended)
    // header('Location: /thank-you.html');
    // exit;

    // Option B: simple inline confirmation
    echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Thank You — " . SITE_NAME . "</title></head>";
    echo "<body style='font-family:Arial,sans-serif;text-align:center;padding:60px 20px;background:#F4F1EC;'>";
    echo "<h2 style='color:#1F3A5F;'>Thank you!</h2>";
    echo "<p style='color:#555;'>Your submission has been received. " . ($ack_sent ? "A confirmation email is on its way to you." : "") . "</p>";
    echo "<a href='/' style='color:#2C7A7B;font-weight:600;'>Return to homepage</a>";
    echo "</body></html>";
} else {
    http_response_code(500);
    echo "Something went wrong sending your submission. Please try again or email us directly at connect@compudonjunior.com.";
}
